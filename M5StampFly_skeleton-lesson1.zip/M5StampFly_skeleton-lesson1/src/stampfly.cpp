#include "stampfly.hpp"

stampfly_t StampFly;
