/*
 * SPDX-FileCopyrightText: 2024 M5Stack Technology CO LTD
 *
 * SPDX-License-Identifier: MIT
 */
#ifndef BUTTON_HPP
#define BUTTON_HPP

bool init_button(void);

#endif